// next.config.js
const withFonts = require("next-fonts");

module.exports = withFonts();
